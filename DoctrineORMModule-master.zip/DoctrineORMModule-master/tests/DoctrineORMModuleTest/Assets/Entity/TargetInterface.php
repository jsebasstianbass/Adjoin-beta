<?php

namespace DoctrineORMModuleTest\Assets\Entity;

interface TargetInterface
{
}
